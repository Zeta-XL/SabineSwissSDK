//
//  AppDelegate.h
//  BluetoothSetDemo
//
//  Created by 赵鑫磊 on 16/6/2.
//  Copyright © 2016年 赵鑫磊. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

