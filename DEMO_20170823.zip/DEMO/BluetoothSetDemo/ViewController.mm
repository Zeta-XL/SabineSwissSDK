//
//  ViewController.m
//  SabineBTSDK
//
//  Created by 赵鑫磊 on 16/5/19.
//  Copyright © 2016年 赵鑫磊. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <EZAudio/EZAudio.h>


#import <SabineSwissSDK/SabineSwissSDK.h>


@interface ViewController () <STDManagerAudioStreamDelegate, EZMicrophoneDelegate>
@property (nonatomic, strong) STCircularPCMBufferModel *pcmBuffer;
@property (weak, nonatomic) IBOutlet UIButton *startButton;
@property (weak, nonatomic) IBOutlet UIButton *stopButton;
@property (weak, nonatomic) IBOutlet UILabel *deviceNameLabel;

@property (weak, nonatomic) IBOutlet UISlider *micGainSlider;
@property (weak, nonatomic) IBOutlet UISlider *monitorSlider;
@property (weak, nonatomic) IBOutlet UISwitch *agcSwitch;

@property (weak, nonatomic) IBOutlet UIStepper *ansStepper;
@property (weak, nonatomic) IBOutlet UILabel *ansLabel;
@property (weak, nonatomic) IBOutlet UISlider *reverbSlider;
@property (weak, nonatomic) IBOutlet UISlider *mixerSlider;
@property (weak, nonatomic) IBOutlet UIButton *firmwareInfoButton;

@property (weak, nonatomic) IBOutlet UILabel *micGainValueLabel;
@property (weak, nonatomic) IBOutlet UILabel *monitorValueLabel;
@property (weak, nonatomic) IBOutlet UILabel *reverbValueLabel;
@property (weak, nonatomic) IBOutlet UILabel *mixerValueLabel;

@property (strong, atomic) EZRecorder *recorder;

@property (assign, nonatomic) FILE *logFile;
@property (assign, nonatomic) BOOL isStart;
@property (assign, nonatomic) UInt64 count;
@property (assign, nonatomic) NSTimeInterval lastTime;
@property (strong, nonatomic) EZMicrophone *micropone;

@property (assign, nonatomic) NSTimeInterval duration;
@end

@implementation ViewController
@synthesize logFile = _logFile;
- (void)setLogFile:(FILE *)logFile {
    if (_logFile != logFile) {
        if (_logFile) {
            fclose(_logFile);
        }
        _logFile = logFile;
        self.count = 0;
    }
}

- (FILE *)logFile {
    if (!_logFile) {
        NSString *docPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
        
        NSString *fileName = [[self formatDate:[NSDate date] usePattern:@"yyyyMMdd_HHmmss"] stringByAppendingPathExtension:@"log"];
        NSString *filePath = [docPath stringByAppendingPathComponent:fileName];
        _logFile = fopen(filePath.UTF8String, "w");
        
    }
    return _logFile;
}


- (NSString *)formatDate:(NSDate *)date usePattern:(NSString *)pattern {
    
    NSDateFormatter *dateFormater = [[NSDateFormatter alloc] init];
    
    dateFormater.dateFormat = pattern;
    dateFormater.locale = [NSLocale currentLocale];
    NSString *formatString = [dateFormater stringFromDate:date];
    return formatString;
}


- (NSTimeInterval)getCurrentTime {
    return [[NSDate date] timeIntervalSince1970];
}

- (void)writeToLogFileWithCount:(UInt64)count {
    NSTimeInterval current = [self getCurrentTime];
    NSString *logString = [NSString stringWithFormat:@"%llu\t%lf\n", count, (current - self.lastTime)*1000];
    fwrite(logString.UTF8String, 1, logString.length, self.logFile);
    
    self.lastTime = current;
}



//- (void)connectDisplay:(BOOL)isConnect {
//    if (isConnect) {
//        self.connectLabel.text = @"Connected";
//        self.connectLabel.textColor = [UIColor greenColor];
//    } else {
//        self.connectLabel.text = @"Disconnect";
//        self.connectLabel.textColor = [UIColor redColor];
//    }
//}



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self addNotification];
    [self uiConfig];
    
    [[STDManager sharedInstance] STD_Connect];
//    [STDManager sharedInstance].sampleRate = STDAudioSampleRate44100;
    
    // 如果使用了内置mic, 请留意该方法中的设置
    [self setupBuildInMicPhone];
    
}

- (void)uiConfig {
    self.micGainSlider.value = [STDManager sharedInstance].micGain/20.0;
    self.micGainValueLabel.text = [NSString stringWithFormat:@"%ld", [STDManager sharedInstance].micGain*5];
    
    self.monitorSlider.value = [STDManager sharedInstance].monitor/20.0;
    self.monitorValueLabel.text = [NSString stringWithFormat:@"%ld", [STDManager sharedInstance].monitor*5];
    self.agcSwitch.on = [STDManager sharedInstance].agcOn;
    if (self.agcSwitch.isOn) {
        self.micGainSlider.enabled = NO;
    }
    self.ansStepper.value = [STDManager sharedInstance].ans;
    self.ansLabel.text = [NSString stringWithFormat:@"%.f", self.ansStepper.value];
    
    self.reverbSlider.value = [STDManager sharedInstance].reverb/20.0;
    self.reverbValueLabel.text = [NSString stringWithFormat:@"%ld", [STDManager sharedInstance].reverb*5];
    
    self.mixerSlider.value = [STDManager sharedInstance].mixer/20.0;
    self.mixerValueLabel.text = [NSString stringWithFormat:@"%ld", [STDManager  sharedInstance].mixer*5];
    [self configWithDeviceType:[STDManager sharedInstance].deviceType];
}


- (void)configWithDeviceType:(STDHardwardType)deviceType {
    NSString *deviceName = @"无";
    switch (deviceType) {
        case STDHardwardTypeNone:
            
            break;
        case STDHardwardTypeAlayaPro:
            deviceName = @"Alaya Pro";
            break;
        
        case STDHardwardTypeAlayaSilver:
            deviceName = @"Alaya Silver";
            break;
            
        case STDHardwardTypeSMIC:
            deviceName = @"SMIC";
            
        default:
            break;
    }
    
    if ([NSThread currentThread].isMainThread) {
        self.deviceNameLabel.text = [NSString stringWithFormat:@"设备状态: %@", deviceName];
    } else {
        dispatch_async(dispatch_get_main_queue(), ^{
            self.deviceNameLabel.text = [NSString stringWithFormat:@"设备状态: %@", deviceName];
        });
    }
    
    
    
}

- (void)setupBuildInMicPhone {
    self.micropone = [EZMicrophone microphoneWithDelegate:self
                          withAudioStreamBasicDescription:[STAudioStreamBasicFormat inputFormat]];
    NSError *error = nil;
    [[AVAudioSession sharedInstance] setActive:NO error:&error];
    if (error) {
        NSLog(@"Error: %@", error.localizedDescription);
    }
    
    // TODO: AVAudioSessionCategoryOption 中不要设置AVAudioSessionCategoryOptionAllowBluetooth
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord
                                     withOptions:(AVAudioSessionCategoryOptionMixWithOthers)
                                           error:&error];
    if (error) {
        NSLog(@"Error: %@", error.localizedDescription);
    }
    
//    [[AVAudioSession sharedInstance] setActive:YES error:&error];
//    if (error) {
//        NSLog(@"Error: %@", error.localizedDescription);
//    }
    // 开启内置mic, 接收数据
    if (!self.micropone.microphoneOn) {
        self.micropone.microphoneOn = YES;
    }
    
}

- (void)microphone:(EZMicrophone *)microphone hasBufferList:(AudioBufferList *)bufferList withBufferSize:(UInt32)bufferSize withNumberOfChannels:(UInt32)numberOfChannels {
    NSLog(@"这是内置mic接收的数据: %u", bufferSize);
}


- (NSURL *)makeAudioFileURLWithExt:(NSString *)ext {
    
    return [NSURL fileURLWithPath:[self makeAudioFilePathWithExt:ext]];
}

- (NSString *)makeAudioFilePathWithExt:(NSString *)ext {
    NSString *docPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    NSString *fileName = [@"测试音频" stringByAppendingPathExtension:ext];
    NSString *filePath = [docPath stringByAppendingPathComponent:fileName];
    return filePath;
}


- (void)addNotification {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(connectStateDidChange:) name:STAccessoryConnectStateChangeNotification object:nil];
}


- (void)connectStateDidChange:(NSNotification *)noti {
//   [self connectDisplay:[STDManager sharedInstance].isConnect];
    
    [self configWithDeviceType:[STDManager sharedInstance].deviceType];
    
    
    if ([STDManager sharedInstance].isConnect) {
//        [self startAction:nil];
        NSLog(@"Device Type: %ld", [STDManager sharedInstance].deviceType);
    }

}

#pragma mark -- Button Actions
- (IBAction)startAction:(UIButton *)sender {
    if (![STDManager sharedInstance].isConnect) {
        return;
    }
    
    self.startButton.enabled = NO;
    [self setupRecorder];
    [[STDManager sharedInstance] STDR_StartWithDelegate:self];
    self.lastTime = [self getCurrentTime];
    self.duration = 0.0;
    self.isStart = YES;
    
    [self.startButton setTitle:@"00:00" forState:(UIControlStateDisabled)];
    NSLog(@"Start recording");
}




// 此方法用来初始化录音器,用于存成文件;
// 对于各直播平台, 请使用自己的编码器, 需要设置采样率, 声道数等信息
- (void)setupRecorder {
    // aac_adts
    self.recorder = [EZRecorder recorderWithURL:[self makeAudioFileURLWithExt:@"aac"]
                                   clientFormat:[STAudioStreamBasicFormat inputFormat]
                                     fileFormat:[STAudioStreamBasicFormat aacFileFormat]
                                audioFileTypeID:kAudioFileAAC_ADTSType];
    //
    //    self.recorder = [EZRecorder recorderWithURL:[self makeAudioFileURLWithExt:@"m4a"]
    //                                  clientFormat:[STAudioStreamBasicFormat inputFormat]
    //                                    fileFormat:[STAudioStreamBasicFormat aacFileFormat]
    //                               audioFileTypeID:kAudioFileM4AType];
    
    // wav
//        self.recorder = [EZRecorder recorderWithURL:[self makeAudioFileURLWithExt:@"wav"]
//                                       clientFormat:[STAudioStreamBasicFormat inputFormat]
//                                         fileFormat:[STAudioStreamBasicFormat wavFileFormat]
//                                    audioFileTypeID:kAudioFileWAVEType];

}



- (IBAction)stopAction:(UIButton *)sender {
    if (![STDManager sharedInstance].isConnect) {
        return;
    }
    
    self.isStart = NO;
    self.logFile = NULL;
    [self.recorder closeAudioFile];
    self.recorder = nil;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [[STDManager sharedInstance] STDR_Stop];
        self.startButton.enabled = YES;
        self.startButton.titleLabel.text = @"开始录制";
        [self.startButton setTitle:@"开始录制" forState:(UIControlStateNormal)];
    });
    
    
    NSLog(@"Stop Recording");
}

- (IBAction)micGainSliderValueChange:(UISlider *)sender {
    NSInteger index = roundf(sender.value*100);
    self.micGainValueLabel.text = [NSString stringWithFormat:@"%ld", index];
}

- (IBAction)micGainSliderTouchEnd:(UISlider *)sender {
    NSInteger index = roundf(sender.value*20);
    [STDManager sharedInstance].micGain = index;
}

- (IBAction)monitorSliderValueChange:(UISlider *)sender {
    NSInteger index = roundf(sender.value*100);
    self.monitorValueLabel.text = [NSString stringWithFormat:@"%ld", index];
}

- (IBAction)monitorSliderTouchEnd:(UISlider *)sender {
    NSInteger index = roundf(sender.value*20);
    [STDManager sharedInstance].monitor = index;
}



- (IBAction)agcSwitchValueChanged:(UISwitch *)sender {
    [STDManager sharedInstance].agcOn = sender.isOn;
    self.micGainSlider.enabled = !sender.isOn;
}

- (IBAction)ansStepperValueChanged:(UIStepper *)sender {
    
    NSInteger value = sender.value;
    [STDManager sharedInstance].ans = value;
    self.ansLabel.text = [NSString stringWithFormat:@"%ld", value];
    
}


- (IBAction)revervSliderValueChange:(UISlider *)sender {
    NSInteger index = roundf(sender.value*100);
    self.reverbValueLabel.text = [NSString stringWithFormat:@"%ld", index];
}


- (IBAction)reverbSliderTouchEnd:(UISlider *)sender {
    if ([STDManager sharedInstance].deviceType == STDHardwardTypeSMIC) {
        NSInteger index = roundf(sender.value*20);
        [STDManager sharedInstance].reverb = index;
    }
}

- (IBAction)mixerSliderValueChange:(UISlider *)sender {
    NSInteger index = roundf(sender.value*100);
    self.mixerValueLabel.text = [NSString stringWithFormat:@"%ld", index];
}


- (IBAction)mixerSliderTouchEnd:(UISlider *)sender {
    NSInteger index = roundf(sender.value*20);
    [STDManager sharedInstance].mixer = index;
}

- (IBAction)onFirmwareInfoPress:(UIButton *)sender {
    if (![STDManager sharedInstance].isConnect) {
        return;
    }
    NSString *message = [NSString stringWithFormat:@"固件版本: %@", [STDManager sharedInstance].firmwareVersion];
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"硬件信息"
                                                                             message:message
                                                                      preferredStyle:(UIAlertControllerStyleAlert)];
    
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:(UIAlertActionStyleDefault)
                                                   handler:^(UIAlertAction * _Nonnull action) {
                                                       [alertController dismissViewControllerAnimated:YES completion:nil];
                                                   }];
    [alertController addAction:action];
    [self presentViewController:alertController animated:YES completion:nil];
    
    
}

#pragma mark -- Pcm Circular Buffer Delegate
- (void)STD_PCMBuffer:(STCircularPCMBufferModel *)pcmBuffer didReceivePCMBytes:(Byte *)pcm pcmByteSize:(SInt32)pcmSize {
    if (self.isStart) {
        [self writeToLogFileWithCount:self.count];
        self.count ++;
    }
    
    AudioBufferList *bufferList = [pcmBuffer readAudioBufferListWithAudioBufferSize:1024*[STAudioStreamBasicFormat inputFormat].mBytesPerFrame];
    if (!!bufferList) {
         NSLog(@"time value: %lld scale: %d", [pcmBuffer currentTimeStampSince1970].value, [pcmBuffer currentTimeStampSince1970].timescale);
        if (self.recorder) {
            if (self.isStart) {
                [self.recorder appendDataFromBufferList:bufferList withBufferSize:1024];
                
                self.duration += 1024.0/[STDManager sharedInstance].sampleRate;
                [self configRecordingDuration:self.duration];
                
            }

        }
        
    }
                                                                                                      
}

- (void)configRecordingDuration:(NSTimeInterval)duration {
    NSString *timeStr = nil;
    if (duration >= 3600 ) {
        NSInteger hour = (NSInteger)duration / 3600;
        NSInteger tmpMinute = (NSInteger)duration % 3600;
        NSInteger minute = tmpMinute / 60;
        NSInteger second = tmpMinute % 60;
        timeStr = [NSString stringWithFormat:@"%02ld:%02ld:%02ld", hour, minute, second];
    }else {
        NSInteger minute = (NSInteger)duration / 60;
        NSInteger second = (NSInteger)duration % 60;
        timeStr = [NSString stringWithFormat:@"%02ld:%02ld", minute, second];
    }
    
    void (^operation)() = ^{
        if (self.startButton.enabled) {
            self.startButton.enabled = NO;
        }
        self.startButton.titleLabel.text = timeStr;
        [self.startButton setTitle:timeStr forState:(UIControlStateDisabled)];
        
    };
    
    if ([NSThread currentThread].isMainThread) {
        operation();
    } else {
        dispatch_async(dispatch_get_main_queue(), ^{
            operation();
        });
    }
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
